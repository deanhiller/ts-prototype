// eslint-disable-next-line no-console
console.log(`**************************************************************
*                                                            *
*  Fuse React Development:                                   *
*                                                            *
*  You are running a development build of Fuse React.        *
*                                                            *
*  Visit the link below to learn more about the Fuse React   *
*  https://fusetheme.com/admin-templates/react/              *
*                                                            *
*  Get github invitation for future updates:                 * 
*  http://support.withinpixels.com/github                    *
*                                                            *
*  Get princing information and FAQs at:                     *
*  https://fusetheme.com/pricing/                            *
*                                                            *
*  Thanks for choosing Fuse React!                           * 
**************************************************************`);
