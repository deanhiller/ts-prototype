import FirebaseSignUpForm from '../../../auth/services/firebase/components/FirebaseSignUpForm';

function FirebaseSignUpTab() {
	return <FirebaseSignUpForm />;
}

export default FirebaseSignUpTab;
