import JwtSignUpForm from '../../../auth/services/jwt/components/JwtSignUpForm';

function JwtSignUpTab() {
	return <JwtSignUpForm />;
}

export default JwtSignUpTab;
