import FirebaseSignInForm from '../../../auth/services/firebase/components/FirebaseSignInForm';

function FirebaseSignInTab() {
	return <FirebaseSignInForm />;
}

export default FirebaseSignInTab;
